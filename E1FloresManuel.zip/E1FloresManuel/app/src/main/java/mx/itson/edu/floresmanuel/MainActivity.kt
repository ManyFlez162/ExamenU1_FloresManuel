package mx.itson.edu.floresmanuel

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val price: EditText = findViewById(R.id.price)
        val ten: Button = findViewById(R.id.ten)
        val fifteen: Button = findViewById(R.id.fifteen)
        val twenty: Button = findViewById(R.id.twenty)
        val twentyfive: Button = findViewById(R.id.twentyfive)
        val thirty: Button = findViewById(R.id.thirteen) //Aquí tuve que poner los números mal pq los edité en el xml así, y si les cambio el nombre se cambian todas las referencias y quita tiempo volver a acomodar
        val fourty: Button = findViewById(R.id.fourteen)

        var precio: Int = price.text.p

        if (price.text.isNotEmpty()){
            ten.setOnClickListener{

            }

            fifteen.setOnClickListener{

            }

            twenty.setOnClickListener {

            }

            twentyfive.setOnClickListener {

            }

            thirty.setOnClickListener {

            }

            fourty.setOnClickListener {

            }

        }

    }

    fun calculaTip(): Double{

    }

    fun calculaDiscount(): Double{

    }

    fun calculaPorcentaje(): Double{

    }

}
